package Practiseproject.Practise24;

import java.util.Scanner;

public class ScannerExample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*System.out.println("example 3");
		Scanner sc=new Scanner(System.in);
         System.out.println("================================");
         for(int j=0;j<3;j++)
         {
             String s1=sc.next();
             int x=sc.nextInt();
             //Complete this line
             //System.out.println();
           //  System.out.printf("%-15s%03d%n", s1, x);
         //	System.out.println("%-15s%03d\n",s1,j);

         }
         System.out.println("================================");
+01
 }*/

		Scanner sc = new Scanner(System.in);
		System.out.println("================================");
		String [] splitLine;
		String s;
		int i;
		while(sc.hasNextLine()){
			splitLine = sc.nextLine().split(" ");
			s = splitLine[0];
			i = Integer.parseInt(splitLine[1]);
			System.out.printf("%-15s%03d\n",s,i);
		}
		System.out.println("================================");
		sc.close();

	}

}
