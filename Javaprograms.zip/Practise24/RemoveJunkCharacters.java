package Practiseproject.Practise24;

public class RemoveJunkCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="Selenium*532*(^#@$";
s=s.replaceAll("[^a-zA-Z0-9]", "");

System.out.println(s);
	}

}
