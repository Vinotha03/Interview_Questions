package JavaExamples2024.javapractise;

public class removeSpecialCharacters {

public void	removeCharacters(){
	String s1="&*Madhavi%$#@";
	String ss="";
	ss+=s1.replaceAll("[^a-zA-Z0-9]", "");
	System.out.println(ss);
	
	}
	
	public static void main(String[] args) {
		removeSpecialCharacters r=new removeSpecialCharacters();
		r.removeCharacters();
		/*String s="Interview%^&#$";
		String ss=s.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(ss);*/
	}

}
