package Practiseproject.Practise24;

public class ApexonTest {
	

	static int i=3;

	public static void main(String args[]) {

			for(int i=0; i<2; i++) {
				counter(i);
			}
			i++;
			System.out.println(i);
			/*System.out.println(10 + 20 + "Javatpoint");   
            System.out.println("Javatpoint" + 10 + 20); */
	   }

	public static void counter(int i) {	
		System.out.println(++i);
	}
}





