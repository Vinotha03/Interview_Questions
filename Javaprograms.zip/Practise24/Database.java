package Practiseproject.Practise24;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		/*	Load the jdbc driver
		create a connection to the database
		 */		
		//creates a statement object
		//execute sql queries
		//store the result in result set
		//get the result from result set


		//oracle.jdbc.driver.OracleDriver
		Class.forName("oracle.jdbc.driver.Oracledriver");
		Connection con=DriverManager.getConnection("");
		Statement stmt=con.createStatement();
		ResultSet  res=	stmt.executeQuery("");
		while(res.next()) {
			// Points to first row in the table 
			String val=	res.getString(1);

		}
	}

}
