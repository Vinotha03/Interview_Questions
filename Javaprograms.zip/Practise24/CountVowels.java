package Practiseproject.Practise24;

public class CountVowels {

	
	static int countVowels(String s) {
		int count=0;
		for(int i=0;i<=s.length()-1;i++) {
			char c=	s.charAt(i);
		
		if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U') {
			count++;
			System.out.println("Vowels are: "+c);
		}
		}
		return count;
		
	}
	
	static int occurenceOfCharacter(String s){
		int count=0;
		char c='a';
	
		for(int i=0;i<=s.length()-1;i++) {
		if(s.charAt(i)==c) {
			System.out.println("Repeated Character in a string is: "+c);
			count++;
		}
		}
		return count;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="abceba";
System.out.println(countVowels(s));

System.out.println(occurenceOfCharacter(s));


	}

}
