package Practiseproject.Practise24;

public class ReverseWordInString {

/*	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="Welcome to Java";
String words[]=s.split(" ");
String rev="";

for (String w : words) {
	StringBuffer sb=new StringBuffer(w);
	sb.reverse();
	rev=rev+sb+" "; 
}
System.out.println(rev);
	}*/

	 public static void reverseString(String inputString) {
	
	 String[] words = inputString.split("\\s+");
     
     // Create an empty string to store the reversed output
     String reversedString = "";
     
     // Reverse each word and append to the reversedString
     for (String word : words) {
         // Reverse the current word
         String reversedWord = "";
     //    word.valueOf(i)
         for(int i=0;i<=words.length-1;i++) {
        	 int n=words.toString().indexOf(word)	;
        	 System.out.println(n);
}
        /* for (int i = word.length() - 1; i >= 0; i--) {
             reversedWord += word.charAt(i);
         }
         reversedString += reversedWord + " ";
    */ }
     
     // Trim any trailing whitespace and return the result
    // return reversedString.trim();
 }
 
 public static void main(String[] args) {
     String inputString = "This interview is on Test Automation";
     reverseString(inputString);
   //  String outputString = reverseString(inputString);
     //System.out.println(outputString);
 }



}
