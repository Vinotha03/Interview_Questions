package Practiseproject.Practise24;

public class SeleniumKeys {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
/*String tab=Keys.chord(Keys.control,Keys.return);
driver.findelement().sendKeys(tab);
*/	}

}
