package Practiseproject.Practise24;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LargestNumber {
	
	public static void collectionSort(Integer[] a) {
		List<Integer> list=Arrays.asList(a);
		
		System.out.println("Size of the Arraylist: "+list.size());
		for (Integer i : list) {
			System.out.println("Elements in the list: "+i);
		}

	//	Collections.sort(list);
		Collections.rotate(list, 2);
		System.out.println(list);
		//System.out.println("largest element: "+list.get(list.size()-1));
		
		}

	public static void arraysSort(Integer[] a) {
		
	Arrays.sort(a);	
	for (Integer i : a) {
		System.out.println(i);
	}
//	System.out.println("Largest Element: "+a[a.length-1]);
	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Integer a[]= {1,2,5,10,27,3,6};
	collectionSort(a);
	//arraysSort(a);
		
}
}