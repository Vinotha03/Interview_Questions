package JavaExamples2024.javapractise;

import java.util.HashMap;
import java.util.Map.Entry;

public class FrequencyOfElementInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int arr[] =new int[]{1,2,4,2,5,6};
		int a[]=new int[5];
		int b[]= {1,2,3,4,5,32,1};
		*/
		int ar[]=new int[] {1,2,3,2,5,4,3,5,6,5};
		HashMap<Integer,Integer> hm=new HashMap<Integer, Integer>();
		
		for(int i=0;i<ar.length;i++) {
		
		if(hm.containsKey(ar[i])) {
			
			hm.put(ar[i], hm.get(ar[i])+1);
		}else {
			hm.put(ar[i], 1);
		}
			
		
	}
		
		for (Entry<Integer,Integer> entry : hm.entrySet()) {
			System.out.println("Number "+ entry.getKey()+" occurred "+entry.getValue());
		}
		
	}

}
