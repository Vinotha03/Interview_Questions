package Practiseproject.Practise24;

public class CheckLargestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		int c=27;
		
		int largest=c>(a>b?a:b)?c:(a>b?a:b);
		System.out.println(largest+" is the largest");
	}

}
