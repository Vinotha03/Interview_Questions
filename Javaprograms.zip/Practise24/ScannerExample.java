package Practiseproject.Practise24;

import java.util.Scanner;

public class ScannerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		System.out.println("Example 1");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int c=sc.nextInt();
		int b=sc.nextInt();
		
		//sc.close();
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println("Example 2");
		Scanner scan=new Scanner(System.in);
		int i = scan.nextInt();
		Double d=scan.nextDouble();
		String s=scan.next();
		//s=scan.nextLine();
		scan.close();
		// Write your code here.

		System.out.println("String: " + s);
		System.out.println("Double: " + d);
		System.out.println("Int: " + i);
		
		
		System.out.println("example 3");
		Scanner sc2=new Scanner(System.in);
         System.out.println("================================");
         for(int j=0;j<3;j++)
         {
             String s1=sc.next();
             int x=sc.nextInt();
             //Complete this line
             //System.out.println();
         	System.out.printf("%-15s%03d\n",s,i);

         }
         System.out.println("================================");

 }
		




}
