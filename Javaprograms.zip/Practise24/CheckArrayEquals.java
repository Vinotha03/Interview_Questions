package Practiseproject.Practise24;

import java.util.Arrays;

public class CheckArrayEquals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {1,2,3,4,5};
		int b[]= {1,2,3,4,5,6};
		
		
		//approach 1
		Boolean status=Arrays.equals(a, b);
		
		if(status==true) {
			System.out.println("arrays are equal");
		}else {
			System.out.println("arrays are not equal");
		}

	
	
	
	
	
	
	
	
	
	
	}

}
