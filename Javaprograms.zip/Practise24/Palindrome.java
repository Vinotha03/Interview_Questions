package Practiseproject.Practise24;

import java.util.Scanner;

public class Palindrome {

	public static void isPalindrome(String s) {
		String org=s;

		String rev="";

		for(int i=s.length()-1;i>=0;i--) {		
			rev=rev+s.charAt(i);					
		}	
		System.out.println(rev);

		if(org.equals(rev)) {
			System.out.println(org+" string is a palindrome");
		}else
			System.out.println(org+" string is not a palindrome");
	}


	//Using string buffer
	public static void buffer(String s) {

		StringBuffer sb=new StringBuffer(s);
		sb.reverse();
		System.out.println(sb);

	}

	//Reverse a number
	public static void reverseNum1() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number: ");

		int n=s.nextInt();
	int rev=0;
		while(n!=0) {
			rev=rev*10+n%10;
			n=n/10;
		}
		System.out.println(rev);

	}
	public static void reverseNum2() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n=s.nextInt();
		
		StringBuffer sb=new StringBuffer(String.valueOf(n));
		sb.reverse();
		System.out.println("Reversed number:"+sb);
		
	}
	public static void reverseNum3() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n=s.nextInt();
		
		StringBuffer sb=new StringBuffer();
		StringBuilder sb1=new StringBuilder();
		sb.append(n);
		sb.reverse();
		System.out.println("Reversed number:"+sb);
					

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="racecar";
		String s1="Madhavi";
		/*isPalindrome(s);
		buffer(s1);
		 */
		/*int i=1234;
		reverseNum1(i);
		 */
		//reverseNum1();
		//reverseNum2();
		reverseNum3();
	}

}
