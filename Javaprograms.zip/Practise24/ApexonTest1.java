package Practiseproject.Practise24;

public class ApexonTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(10 + 20 + "Javatpoint");  
		 System.out.println("Javatpoint" + 10);
       // System.out.println("Javatpoint" + 10 + 20); 
		
	}

}
