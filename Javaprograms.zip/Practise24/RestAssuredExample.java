/*package Practiseproject.Practise24;

import static io.restassured.RestAssured.*;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAssuredExample {

	public void getAllEmployees() {
		RestAssured.baseURI="http://localhost:3000/";
		RequestSpecification rs=RestAssured.given();
		Response response=rs.request(Method.GET, "employees");
		System.out.println(response.asPrettyString());
		System.out.println(response.getStatusLine());		

	}
	public void createEmployee() {
		RestAssured.baseURI="http://localhost:3000/";
		RequestSpecification rs=RestAssured.given().header("Content-Type","application/json").body("{\"name\":\"Maddy\",\"salary\":\"10000123\",\"age\":\"27\"}");
		Response res=rs.request(Method.POST, "Employees");
		System.out.println(res.asPrettyString());
		System.out.println(res.getStatusLine());

	}

	public void updateEmployee() {
		
		RestAssured.baseURI="http://localhost:3000/";
		RequestSpecification rs=RestAssured.given().header("Content-type", "application/json").body("{\"name\":\"Maddy\",\"salary\":\"10000123\",\"age\":\"17\"}");
		Response response=rs.request(Method.PUT, "Employees/12");
		System.out.println(response.asPrettyString());
		System.out.println(response.getStatusLine());

	}
	
	public void deleteEmployee() {
		
	RestAssured.baseURI="http://localhost:3000/";
	RequestSpecification rs=RestAssured.given();
	Response response=rs.request(Method.DELETE, "Employee/17");
	
	}
	
	
	public void getSingleEmployee() {
			
		RestAssured.baseURI="http://localhost:3000/";
		RequestSpecification rs=RestAssured.given();
		Response response=rs.request(Method.GET,"employees/7");
		System.out.println(response.asPrettyString());
		System.out.println(response.getStatusLine());			
	}
	//BDD style
	public void getAllEmployeesBDD() {
		//get
		RestAssured.given().baseUri("http://localhost:3000").when().get("/employees").prettyPrint();
		
		//post
		given().baseUri("http://localhost:3000").header("Content-Type","application/json").body("{\"name\":\"Maddy\",\"salary\":\"10000123\",\"age\":\"27\"}")
		.when().post("/employees").prettyPrint();
		
		//put
		given().baseUri("http://localhost:3000").header("Content-Type","application/json").body("{\"name\":\"Maddy\",\"salary\":\"10000123\",\"age\":\"27\"}")
.when().put("/employees/id").prettyPrint();
		
		
		//delete
		
		given()
		.baseUri("http://localhost:3000")
		.when()
		.delete("employee/190")
		.prettyPrint();
	//create employee from json file	
	File jsonFile=new File("postData.json");
			given()
	.baseUri("http://localhost:3000")
	.header("Content-Type","application/json")
	.body(jsonFile)
	.when()
	.post("employees")
	.prettyPrint();
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub



	}



	}


*/