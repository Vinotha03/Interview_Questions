package Practiseproject.Practise24;

import java.util.Arrays;

public class RemoveDuplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] n= {1,3,3,3,27,1};
		int count=0;
		int temp[];
		int num=3;
		//for (int i : i+1) {
			for(int i=0;i<n.length-1;i++) {
			if(i==num) {
			//	temp=i;
			count++;			
			}
			
			
	
		//System.out.println(temp);
		
	}
			System.out.println(count);	
	}
}
