package Practiseproject.Practise24;

public class SwapNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10;int b=20;
		//1
		int t=0;
		t=a;
		a=b;
		b=t;
		
		
		//2
		
		a=a+b;
		b=a-b;
		a=a-b;
		
		
		//3
		a=a*b;
		b=a/b;
		a=a/b;
		
		//4 XOR
		
		a=a^b;
		b=a^b;		
		a=a^b;
		
		//5
		b=a+b-(a=b);
		
		
	}

}
