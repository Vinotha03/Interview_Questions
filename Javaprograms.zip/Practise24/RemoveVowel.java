package Practiseproject.Practise24;

public class RemoveVowel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ss="";
		String s="Madhavi";
		ss+=s.replaceAll("[aeiouAEIOU]", "");
			System.out.println(ss);
			
		}
	

}
